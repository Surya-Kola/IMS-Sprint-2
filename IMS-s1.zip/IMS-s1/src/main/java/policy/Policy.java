package policy;

public class Policy {
    private int policyId;
    private String type;
    private double premium;
    private int duration; // in months

    public Policy(int policyId, String type, double premium, int duration) {
        this.policyId = policyId;
        this.type = type;
        this.premium = premium;
        this.duration = duration;
    }

    public int getPolicyId() { return policyId; }
    public String getType() { return type; }
    public double getPremium() { return premium; }
}

