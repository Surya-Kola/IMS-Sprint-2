package customer;

import policy.Policy;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class Customer {
    private int id;
    private String name;
    private String email;
    private String phone;
    private String password;
    private List<Policy> policies;

    public Customer(int id, String name, String email, String phone, String password) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.phone = phone;
        this.password = password;
        this.policies = new ArrayList<>();
    }

    // Getters
    public int getId() {
        return id;
    }
    public String getName() {
        return name;
    }
    public String getEmail() {
        return email;
    }
    public String getPhone() {   // Added getter for phone
        return phone;
    }
    public String getPassword() {
        return password;
    }
    public List<Policy> getPolicies() {
        return policies;
    }

    // Setters for editing customer details (if needed)
    public void setName(String name) {
        this.name = name;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public void setPassword(String password) {
        this.password = password;
    }

    // Policy-related methods
    public void registerPolicy(Policy policy) {
        policies.add(policy);
    }
    public String getPoliciesAsString() {
        if (policies.isEmpty()) return "No Policies Selected";
        return policies.stream()
                .map(p -> p.getPolicyId() + "-" + p.getType())
                .collect(Collectors.joining(", "));
    }
    public List<String> viewPolicies() {
        return policies.stream()
                .map(policy -> "Policy ID: " + policy.getPolicyId() + ", Type: " + policy.getType() + ", Premium: $" + policy.getPremium())
                .collect(Collectors.toList());
    }

    @Override
    public String toString() {
        return "Customer [ID=" + id + ", Name=" + name + ", Email=" + email + ", Phone=" + phone + "]";
    }
}

