package cli;

import customer.Customer;
import policy.Policy;
import util.CustomerDataManager;

import java.io.Console;
import java.util.*;
import java.util.regex.Pattern;

public class CLI {
    // Load customers from the file at startup
    private static final List<Customer> customers = CustomerDataManager.loadCustomers();
    private static Customer loggedInUser;
    private static final List<Policy> insurancePolicies = new ArrayList<>();

    public static void main(String[] args) {
        // Initialize some bank policies
        insurancePolicies.add(new Policy(101, "Health", 200.0, 12));
        insurancePolicies.add(new Policy(102, "Car", 150.0, 6));
        insurancePolicies.add(new Policy(103, "Home", 250.0, 12));

        Scanner scanner = new Scanner(System.in);

        while (true) {
            System.out.println("\n🔹 Welcome to Insurance Management System 🔹");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            //System.out.println("4. Admin");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                System.out.println("❌ Invalid choice! Enter a number.");
                scanner.next();
                continue;
            }

            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1 -> register(scanner);
                case 2 -> login(scanner);
                case 3 -> {
                    System.out.println("🔹 Exiting... Thank you!");
                    return;
                }
//                case 4 -> {
//                    // Ask for admin credentials
//                    if (adminLogin(scanner)) {
//                        AdminManager adminManager = new AdminManager(customers);
//                        adminManager.adminMenu(scanner);
//                        // Save any changes made by admin.
//                        CustomerDataManager.saveCustomers(customers);
//                    } else {
//                        System.out.println("❌ Invalid admin credentials. Returning to main menu.");
//                    }
//                }
                default -> System.out.println("❌ Invalid choice! Please select again.");
            }
        }
    }

    private static void register(Scanner scanner) {
        System.out.print("? Enter Name: ");
        String name = scanner.nextLine().trim();
        if (name.isEmpty()) {
            System.out.println("❌ Name cannot be empty. Registration cancelled.");
            return;
        }

        // Validate email using a generic pattern and check if already registered
        System.out.print("? Enter Email: ");
        String email = scanner.nextLine().trim();
        if (email.isEmpty()) {
            System.out.println("❌ Email cannot be empty. Registration cancelled.");
            return;
        }
        if (!email.matches("^[a-z0-9._%+-]+@[a-z0-9.-]+\\.com")) {
            System.out.println("❌ Invalid email address! Registration cancelled.");
            return;
        }
        boolean exists = customers.stream()
                .anyMatch(c -> c.getEmail().equalsIgnoreCase(email));
        if (exists) {
            System.out.println("❌ This email is already registered. Please login or use a different email.");
            return;
        }

        System.out.print("? Enter Country Code: ");
        String countryCode = scanner.nextLine().trim();
        if (countryCode.isEmpty()) {
            System.out.println("❌ Country code cannot be empty. Registration cancelled.");
            return;
        }

        System.out.print("? Enter Phone (10 digits): ");
        String phone = scanner.nextLine().trim();
        if (!phone.matches("\\d{10}")) {
            System.out.println("❌ Invalid phone number! Please enter exactly 10 digits. Registration cancelled.");
            return;
        }
        String fullPhone = countryCode + phone;

        // Loop until a valid password is provided.
        String password;
        while (true) {
            password = getHiddenPassword("🔹 Enter Password: ", scanner);
            if (password.isEmpty()) {
                System.out.println("❌ Password cannot be empty. Try again.");
                continue;
            }
            // Regex: At least one uppercase, one digit, one special character, and length 8-25.
            if (!password.matches("^(?=.*[A-Z])(?=.*\\d)(?=.*[^A-Za-z0-9]).{8,25}$")) {
                System.out.println("❌ Password must be 8-25 characters long, contain at least one uppercase letter, one number, and one special character.");
                continue;
            }
            String confirmPassword = getHiddenPassword("🔹 Confirm Password: ", scanner);
            if (!password.equals(confirmPassword)) {
                System.out.println("❌ Passwords do not match! Try again.");
                continue;
            }
            break;  // Valid password provided.
        }

        Customer customer = new Customer(customers.size() + 1, name, email, fullPhone, password);
        customers.add(customer);
        System.out.println("✅ Registration successful! Now login.");

        // Save the new customer data to file.
        CustomerDataManager.saveCustomers(customers);
    }


    private static void login(Scanner scanner) {
        System.out.print("\n🔹 Enter Email: ");
        String email = scanner.nextLine();
        String password = getHiddenPassword("🔹 Enter Password: ", scanner);

        Optional<Customer> customerOpt = customers.stream()
                .filter(c -> c.getEmail().equalsIgnoreCase(email) && c.getPassword().equals(password))
                .findFirst();

        if (customerOpt.isPresent()) {
            loggedInUser = customerOpt.get();
            System.out.println("✅ Login successful! Welcome, " + loggedInUser.getName());
            showMenu(scanner);
        } else {
            System.out.println("❌ Invalid email or password.");
        }
    }

    private static void showMenu(Scanner scanner) {
        while (loggedInUser != null) {
            System.out.println("\n1. View and Select Policies");
//            System.out.println("2. View Profile");
            System.out.println("2. Update Profile");
            System.out.println("3. Logout");
            System.out.print("Choose an option: ");

            if (!scanner.hasNextInt()) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.next(); // consume the invalid input
                continue;
            }
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume the newline

            switch (choice) {
                case 1 -> viewPolicies(scanner);
                case 2 -> updateProfile(scanner);
                case 3 -> {
                    System.out.println("Logging out.");
                    loggedInUser = null;
                }
                default -> System.out.println("Invalid option, please try again.");
            }
        }
    }

    private static void viewPolicies(Scanner scanner) {
        System.out.println("\nAvailable Bank Policies:");
        for (int i = 0; i < insurancePolicies.size(); i++) {
            Policy p = insurancePolicies.get(i);
            System.out.println((i + 1) + ". Policy ID: " + p.getPolicyId() + ", Type: " + p.getType() + ", Premium: $" + p.getPremium());
        }
        System.out.print("Enter the number of the policy you want to register, or 0 to cancel: ");

        if (!scanner.hasNextInt()) {
            System.out.println("❌ Invalid input!");
            scanner.next();
            return;
        }
        int selection = scanner.nextInt();
        scanner.nextLine(); // consume newline

        if (selection > 0 && selection <= insurancePolicies.size()) {
            Policy selected = insurancePolicies.get(selection - 1);
            loggedInUser.registerPolicy(selected);
            System.out.println("✅ Policy registered successfully!");

            // Save updated customer data to the file
            CustomerDataManager.saveCustomers(customers);
        } else {
            System.out.println("Operation cancelled.");
        }
    }

    private static String getHiddenPassword(String prompt, Scanner scanner) {
        Console console = System.console();
        if (console != null) {
            char[] pwd = console.readPassword(prompt);
            return new String(pwd);
        } else {
            System.out.print(prompt);
            return scanner.nextLine();
        }
    }

    private static void updateProfile(Scanner scanner) {
        System.out.print("Enter your new name (leave blank to keep current): ");
        String name = scanner.nextLine();
        if (!name.trim().isEmpty()) {
            loggedInUser.setName(name.trim());
        }

        String newEmail;
        while (true) {
            System.out.print("Enter your new email (leave blank to keep current): ");
            newEmail = scanner.nextLine();
            if (newEmail.trim().isEmpty()) {
                break;
            }
            if (Pattern.matches("^[A-Za-z0-9+_.-]+@(.+)$", newEmail)) {
                final String finalEmail = newEmail;
                boolean exists = customers.stream().anyMatch(c -> c.getEmail().equalsIgnoreCase(finalEmail) && !c.equals(loggedInUser));
                if (!exists) {
                    loggedInUser.setEmail(finalEmail);
                    break;
                } else {
                    System.out.println("Email is already registered to another user. Try another.");
                }
            } else {
                System.out.println("Invalid email format.");
            }
        }

        System.out.print("Enter your new 10-digit phone number (leave blank to keep current): ");
        String phoneNumber;
        while (true) {
            phoneNumber = scanner.nextLine();
            if (phoneNumber.trim().isEmpty() || (phoneNumber.length() == 10 && Pattern.matches("\\d{10}", phoneNumber))) {
                if (!phoneNumber.trim().isEmpty()) loggedInUser.setPhone(phoneNumber);
                break;
            }
            System.out.println("Phone number must be 10 digits. Enter again: ");
        }

        while (true) {
            String password = getHiddenPassword("Enter your new password (press Enter to keep current): ",scanner);
            if (password.isEmpty()) {
                break;
            }
            String confirmPassword = getHiddenPassword("Confirm your new password: ",scanner);
            if (password.equals(confirmPassword)) {
                loggedInUser.setPassword(password);
                break;
            } else {
                System.out.println("Passwords do not match. Please try again.");
            }
        }

        // After updating the user details in memory
        CustomerDataManager.updateCustomer(loggedInUser);  // Save updated details back to the file
        System.out.println("Profile updated successfully.");
    }



    // Expose the customer list for admin use
    public static List<Customer> getCustomers() {
        return customers;
    }

    // Admin login method
//    private static boolean adminLogin(Scanner scanner) {
//        System.out.println("\n===== Admin Login =====");
//        System.out.print("Enter admin username: ");
//        String username = scanner.nextLine();
//        String password = getHiddenPassword("🔹 Enter admin password: ", scanner);
//        if (username.equals("admin") && password.equals("admin123")) {
//            System.out.println("✅ Admin login successful.");
//            return true;
//        } else {
//            System.out.println("❌ Invalid admin credentials.");
//            return false;
//        }
//    }
}

