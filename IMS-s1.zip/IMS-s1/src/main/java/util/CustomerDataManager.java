package util;

import customer.Customer;
import java.io.*;
import java.util.ArrayList;
import java.util.List;
import policy.Policy;

public class CustomerDataManager {
    private static final String FILE_NAME = "src/main/java/util/customer.txt";

    // Save the list of customers to a text file.
    public static void saveCustomers(List<Customer> customers) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(FILE_NAME))) {
            for (Customer customer : customers) {
                String record = "ID: " + customer.getId() + " | Name: " + customer.getName() +
                        " | Email: " + customer.getEmail() + " | Phone: " + customer.getPhone() +
                        " | Password: " + customer.getPassword() + " | Policies: " + customer.getPoliciesAsString();
                writer.write(record);
                writer.newLine();
            }
//            System.out.println("✅ Customers saved successfully to " + FILE_NAME);
        } catch (IOException e) {
            System.err.println("❌ Error saving customers: " + e.getMessage());
        }
    }

    // Load customers from the text file and return them as a list.
    public static List<Customer> loadCustomers() {
        List<Customer> customers = new ArrayList<>();
        File file = new File(FILE_NAME);
        if (!file.exists()) {
            return customers;
        }
        try (BufferedReader reader = new BufferedReader(new FileReader(FILE_NAME))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] parts = line.split("\\s*\\|\\s*");
                if (parts.length < 6) continue;

                int id = Integer.parseInt(parts[0].replace("ID: ", ""));
                String name = parts[1].replace("Name: ", "");
                String email = parts[2].replace("Email: ", "");
                String phone = parts[3].replace("Phone: ", "");
                String password = parts[4].replace("Password: ", "");
                String policiesString = parts.length > 6 ? parts[5].replace("Policies: ", "") : "No Policies Selected";

                Customer customer = new Customer(id, name, email, phone, password);

                // Load policies if any exist
                if (!policiesString.equals("No Policies Selected")) {
                    String[] policyEntries = policiesString.split(", ");
                    for (String entry : policyEntries) {
                        String[] policyParts = entry.split("-");
                        if (policyParts.length == 2) {
                            int policyId = Integer.parseInt(policyParts[0]);
                            String policyType = policyParts[1];
                            customer.registerPolicy(new Policy(policyId, policyType, 0, 0)); // Dummy values for premium and duration
                        }
                    }
                }

                customers.add(customer);
            }
        } catch (IOException e) {
            System.err.println("❌ Error loading customers: " + e.getMessage());
        }
        return customers;
    }
    // Update a specific customer and save changes
    public static void updateCustomer(Customer updatedCustomer) {
        List<Customer> customers = loadCustomers();
        for (int i = 0; i < customers.size(); i++) {
            if (customers.get(i).getId() == updatedCustomer.getId()) {
                customers.set(i, updatedCustomer);
                break;
            }
        }
        saveCustomers(customers);
    }
}
